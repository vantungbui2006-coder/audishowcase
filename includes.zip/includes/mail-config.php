<?php
/**
 * includes/mail-config.php — CẤU HÌNH GMAIL ĐỂ GỬI EMAIL
 *
 * ⚠️ BẮT BUỘC PHẢI SỬA 3 DÒNG BÊN DƯỚI trước khi form hoạt động được.
 * Xem hướng dẫn lấy "Mật khẩu ứng dụng" (App Password) ở file
 * HUONG_DAN_GMAIL.md đi kèm.
 *
 * ⚠️ LƯU Ý BẢO MẬT: file này chứa mật khẩu — với đồ án học tập chạy
 * trên máy cá nhân thì không sao, nhưng TUYỆT ĐỐI không đưa file này
 * lên GitHub công khai hoặc gửi cho người khác.
 */

// 1. Địa chỉ Gmail của BẠN (nơi gửi email đi, và cũng là nơi nhận thông báo)
define('MAIL_GMAIL_ADDRESS', 'vantungbui2006@.com');

// 2. Mật khẩu ỨNG DỤNG 16 ký tự (KHÔNG PHẢI mật khẩu Gmail thường)
//    Dạng: 'abcd efgh ijkl mnop' — dán nguyên cả dấu cách cũng được, code tự xử lý
define('MAIL_GMAIL_APP_PASSWORD', 'zxmh bzbs xvan apsy');

// 3. Email nhận thông báo — thường để giống MAIL_GMAIL_ADDRESS ở trên
//    (bạn tự gửi cho chính mình), nhưng có thể đổi sang email khác nếu muốn
define('MAIL_ADMIN_RECEIVER', 'vantungbui2006@.com');

// Tên hiển thị khi email gửi tới bạn (không cần sửa)
define('MAIL_SENDER_NAME', 'Audi Showcase - Website Demo');
