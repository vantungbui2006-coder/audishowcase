<?php
/**
 * db.php — Kết nối database dùng chung cho toàn bộ site.
 * Mọi trang PHP cần dữ liệu chỉ cần: require_once 'includes/db.php';
 * rồi dùng biến $pdo.
 *
 * Dùng PDO thay vì mysqli vì: hỗ trợ prepared statements dễ dàng
 * (chống SQL Injection), API nhất quán hơn, dễ đổi sang DB khác sau này.
 */

$host   = 'localhost';
$dbname = 'audi_showcase';
$user   = 'root';      // mặc định XAMPP/WAMP là 'root'
$pass   = '';           // mặc định XAMPP không có mật khẩu

// ---------- Tự động đổi thông tin kết nối khi chạy trên hosting thật ----------
// $_SERVER['SERVER_NAME'] là 'localhost' khi chạy trên máy bạn (XAMPP),
// và là domain thật (VD: yourname.infinityfreeapp.com) khi chạy trên hosting.
// Nhờ đoạn if này, 1 file db.php DÙNG CHUNG được cho cả 2 môi trường —
// không cần sửa code mỗi lần chuyển qua lại giữa localhost và hosting thật.
if ($_SERVER['SERVER_NAME'] !== 'localhost') {
    // ⚠️ SAU KHI TẠO HOSTING XONG, THAY 4 GIÁ TRỊ DƯỚI ĐÂY bằng thông tin
    // MySQL thật lấy từ Control Panel của hosting (mục "MySQL Databases").
        $host   = 'sql105.infinityfree.com';
    $dbname = 'if0_43003740_audi_showcase';
    $user   = 'if0_43003740';
    $pass   = 'VanTungBui2006';
}

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $user,
        $pass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    // Trong đồ án: hiển thị lỗi trực tiếp để dễ debug.
    // Nếu triển khai thật: KHÔNG bao giờ echo lỗi chi tiết ra ngoài,
    // vì nó có thể lộ thông tin cấu trúc database cho kẻ tấn công.
    die("Lỗi kết nối database: " . $e->getMessage());
}
